<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/inlogin.css">
</head>
<body>

<div class="card">
        <form action="">

            <div class="title">
                <p>LOGIN INVÁLIDO</p>
            </div>

            <div class="text">
                <p>Dados do Login incorreto!</p>
                <p>Verifique se o nome e a senha estão corretos!</p>
            </div>
            <div class="bcard">
            <button><a href="./index.php">Voltar</a></button>
            </div>
            
        </form>
    </div>

    
</body>
</html>