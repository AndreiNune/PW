function blockw(keypress) {
    if (keypress>=48 & keypress<=57) {
        return true
    } else {
        return false
    }
}